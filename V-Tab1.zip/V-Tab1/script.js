$(document).ready(function() {

    $(function() {
        var tabContainers = $('.tab_content > .tab_info');

        $('.tab-nav ul li a').click(function() {
            tabContainers.hide().filter(this.hash).show();

            $('.tab-nav ul li a').removeClass('active');
            $(this).addClass('active');

            return false;
        })
    });
    $(".menu-toggle").click(function() {
        $('.menu-toggle').toggleClass('closed');
        $('.navbar').toggleClass('open');
        $('.overlay').toggleClass('active');
    })
    $(".drop_down").click(function() {
        if ($(this).hasClass("active")) {
            $(this).removeClass('active')
            $(this).next().slideUp();
        } else {
            $('.sub_menu').slideUp();
            $('.drop_down').removeClass('active');
            $(this).siblings('.sub_menu').slideToggle();
            $(this).toggleClass('active');
        }
        return false;
    });
    /*
        $(".drop_down").click(function() {
            if ($(window).width() < 769) {
                $(".drop_down").removeClass("active");
                $(".sub_menu").slideUp();
                if (!$(this).next().is(":visible")) {
                    $(this).next().slideDown();
                    $(this).addClass("active");
                }
            }
        })*/
    $('.testimonial_slider').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        arrows: false,
        responsive: [{
                breakpoint: 768,
                settings: {
                    arrows: false,
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    slidesToShow: 1
                }
            }
        ]
    });
});